# Open3DCP manuscript v1.2

Author-approved preprint, 15 September 2026. Not peer reviewed.

Build with Python (matplotlib), Pandoc and XeLaTeX: run source/build.ps1 from PowerShell. CC BY 4.0 for manuscript and original figures. Schema references retain Apache 2.0 attribution.
