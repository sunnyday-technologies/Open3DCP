"""Original, editable vector schematics. All text is black."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Polygon
R=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
BLUE='#436b92'; PALE='#edf2f7'; GREY='#eeeeee'
def setup(w,h):
    f,a=plt.subplots(figsize=(w,h));a.set_xlim(0,1);a.set_ylim(0,1);a.axis('off');f.subplots_adjust(left=.01,right=.99,top=.99,bottom=.01);return f,a
def box(a,x,y,w,h,title,body,fc=PALE):
    a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.01,rounding_size=0.01',facecolor=fc,edgecolor=BLUE,lw=1.2))
    a.text(x+.018,y+h-.065,title,fontsize=15,fontweight='bold',va='top',color='black')
    a.text(x+.018,y+h-.16,body,fontsize=14,va='top',linespacing=1.5,color='black')
def arrow(a,p,q,dashed=False):a.annotate('',xy=q,xytext=p,arrowprops=dict(arrowstyle='->',color=BLUE,lw=1.4,linestyle='--' if dashed else '-'))
def save(f,name):
    for ext in ['pdf','svg','png']: f.savefig(R/'figures'/f'{name}.{ext}',dpi=180,facecolor='white')
    plt.close(f)
f,a=setup(9.5,3.7)
box(a,.015,.35,.27,.61,'SOURCE','Cement: 500 kg/m³\nType: not reported\nBatch sum: 2438 kg/m³\nRow and age retained')
box(a,.355,.35,.285,.61,'FLAT RECORD','cement_unspecified\n20.5086 mass-%\noriginal_basis = kg_m3\nBatch sum retained')
box(a,.705,.35,.275,.61,'CHECK','Recover source quantity\nType stays unknown\nCheck test context\nKeep source links')
arrow(a,(.292,.66),(.343,.66));arrow(a,(.65,.66),(.695,.66))
a.text(.025,.21,'v1.8 adds:',fontweight='bold',fontsize=15)
a.text(.21,.21,'Product + supplier lot',fontsize=15);a.text(.505,.21,'EN cement designation',fontsize=15);a.text(.80,.21,'Aggregate d/D',fontsize=15)
a.text(.5,.065,'Common fields support checking. Comparable experiments need more evidence.',ha='center',fontsize=14)
save(f,'graphical_abstract')
f,a=setup(9.5,3.9)
box(a,.025,.48,.41,.47,'mix_designs','id  |  unique mix_id  |  name\nComposition + selected values\nState how values were obtained')
box(a,.59,.48,.38,.47,'strength_measurements','formulation_id → mix_designs.id\nUnique formulation + age pair\nLimited same-age test detail')
arrow(a,(.445,.7),(.575,.7))
box(a,.025,.045,.41,.28,'SOURCE CONTEXT','Source / method / curing descriptors',GREY)
box(a,.59,.045,.38,.28,'EXTERNAL DETAIL','Specimens / events / raw files',GREY)
arrow(a,(.23,.47),(.23,.34),True);arrow(a,(.40,.48),(.70,.34),True)
save(f,'record_relationships')
f,a=setup(9.5,4.1)
a.text(.02,.94,'MATERIAL FRAME',fontweight='bold')
for j in range(4):a.add_patch(Rectangle((.055,.34+j*.10),.31,.08,facecolor=PALE,edgecolor=BLUE,lw=1))
arrow(a,(.07,.29),(.34,.29));a.text(.10,.20,'U: print path',fontsize=14)
arrow(a,(.035,.34),(.035,.79));a.text(.03,.83,'W: build',fontsize=14)
arrow(a,(.365,.345),(.445,.44));a.text(.375,.49,'V: transverse',fontsize=14)
a.text(.52,.94,'FLEXURAL GEOMETRY: U.W',fontweight='bold')
# Side view: beam axis W; layer planes vertical; applied force U.
a.add_patch(Rectangle((.54,.45),.39,.15,facecolor=PALE,edgecolor=BLUE,lw=1.2))
for x in [.59,.64,.69,.74,.79,.84,.89]:a.plot([x,x],[.45,.60],color=BLUE,lw=1)
for x in [.575,.895]:a.add_patch(Polygon([[x,.445],[x-.017,.40],[x+.017,.40]],facecolor='#b8b8b8',edgecolor='black'))
arrow(a,(.735,.84),(.735,.62));a.text(.76,.76,'Force: U',fontsize=14)
arrow(a,(.71,.37),(.55,.37));arrow(a,(.76,.37),(.92,.37))
a.text(.735,.28,'Tensile stress / beam axis: W',ha='center',fontsize=14)
a.text(.735,.18,'Normal to the layer interfaces',ha='center',fontsize=14)
a.text(.50,.045,'Keep the compound code and test geometry. No universal strength ranking.',ha='center',fontsize=14)
save(f,'orientation')
print('Three vector schematics generated (PDF, SVG and PNG).')
