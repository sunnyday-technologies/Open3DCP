$ErrorActionPreference = 'Stop'
$reviewRoot = Split-Path $PSScriptRoot -Parent
Push-Location $reviewRoot
try {
    python source/make_figures.py
    if ($LASTEXITCODE -ne 0) { throw 'Figure build failed' }
    pandoc Open3DCP_Whitepaper_v1.2.md --standalone --from=markdown --to=latex --output=Open3DCP_Whitepaper_v1.2.tex --include-in-header=source/header.tex --variable=mainfont:'Latin Modern Roman' --variable=sansfont:'Latin Modern Sans' --variable=monofont:'Latin Modern Mono' --variable=fontsize:11pt --variable=geometry:margin=1in --variable=papersize:letter --variable=colorlinks:true --variable=linkcolor:black --variable=urlcolor:black --variable=citecolor:black
    if ($LASTEXITCODE -ne 0) { throw 'Pandoc failed' }
    xelatex -interaction=nonstopmode -halt-on-error -output-directory=qa Open3DCP_Whitepaper_v1.2.tex *> qa/build-pass-1.txt
    if ($LASTEXITCODE -ne 0) { throw 'XeLaTeX first pass failed; inspect qa/build-pass-1.txt' }
    xelatex -interaction=nonstopmode -halt-on-error -output-directory=qa Open3DCP_Whitepaper_v1.2.tex *> qa/build-pass-2.txt
    if ($LASTEXITCODE -ne 0) { throw 'XeLaTeX second pass failed; inspect qa/build-pass-2.txt' }
    Copy-Item qa/Open3DCP_Whitepaper_v1.2.pdf Open3DCP_Whitepaper_v1.2.pdf -Force
} finally { Pop-Location }
